from controller import Robot, Motion

#该控制器仅用来测试motion函数
robot = Robot()
timestep = int(robot.getBasicTimeStep())

try:
    back_motion = Motion('../../motions/SideStepRight.motion') 

except Exception as e:
    back_motion = None

if back_motion:
    back_motion.play()


while robot.step(timestep) != -1:
    if robot.getTime() > 10.0:
        break

