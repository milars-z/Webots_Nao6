from controller import Robot, Keyboard, Motion
from VisionLib import VisionReviewer


GO_FORWARD = 1
GO_BACK    = 2
TURN_RIGHT = 3
TURN_LEFT  = 4
SHOOT      = 0

DOOR_POS_X = -4.25
DOOR_POS_Y = 0

RIGHT_LEG = 0
LEFT_LEG  = 1
TOLERANCE_X = 0.05
TOLERANCE_Y = 0.1

class Logic:
    
    def __init__(self,Nao):

        #self.reciever = vision_reviever(Nao)
        self.reciever = VisionReviewer(Nao)
        self.timeStep = int(Nao.getBasicTimeStep())
        
    def find_state(self):
        door_x    = DOOR_POS_X
        door_y    = DOOR_POS_Y
        tolerance_x = TOLERANCE_X
        tolerance_y = TOLERANCE_Y
        now_state = 'forward'

        #更新接收器收集最新的数据
        #Update the receiver to collect the latest data
        self.reciever.update()
        #获取最新的数据
        #Get the latest data
        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()

        #判断Z轴，如果小于一个值则判断跌倒，直接返回状态
        #Determine the Z-axis, if it is less than one value, determine a fall, and directly return to the state
        if(robot_z != None ):
            if( robot_z < 0.18 ):
                now_state = 'StandUp'
                return now_state

        #如果接收到的数据都不是None
        #接收器可能会接收到None
        #If the received data is not None, the receiver may receive None
        if( (ball_x != None) & (ball_y != None )):
            #根据球的位置找到最佳击球点
            #Find the best hitting point based on the position of the ball
            best_pos_x,best_pos_y = self.find_best_shoot_place(ball_x,ball_y,LEFT_LEG)
            
            #判断机器人与球的距离是否大于一个容忍值
            #Determine whether the distance between the robot and the ball is greater than a tolerance value
            if( abs((door_x - best_pos_x) - (door_x - robot_x)) > tolerance_x ):
                
                #大于的话需要调整，根据大小决定前进后退
                #If it is larger than, it needs to be adjusted according to the size to determine the forward and backward movement
                if ((door_x - best_pos_x) > (door_x - robot_x)):
                    now_state = 'forward'
                elif ((door_x - best_pos_x) < (door_x - robot_x)):
                    now_state = 'back'

            #同理判断y轴，逻辑写的不好，下个版本修改
            #Similarly, judging the y-axis, if the logic is not well written, it will be modified in the next version
            elif((robot_y - ball_y) < 0.0):
                now_state = 'turn_right'
            elif((robot_y - ball_y) > 0.12):
                now_state = 'turn_left'
            
            #x，y轴都满足条件，则踢球
            #x. If both y-axis conditions are met, then kick the ball
            else:
                now_state = 'kick'

        return now_state
    


    def find_best_shoot_place(self,ball_x,ball_y,shoot_leg):
        
        #接受球门的位置，y轴位置后期会在计算角度时用到
        #Accept the position of the goal, and the y-axis position will be used in calculating the angle later on
        door_x = DOOR_POS_X
        door_y = DOOR_POS_Y 

        # multi_bias
        #区分球门的左右位置
        #Distinguish the left and right positions of the goal
        if( door_x > 0 ):
            multi_bias =  1
        else: 
            multi_bias = -1

        #通过接受用左脚击球还是右脚击球来设置偏移，该版本没用到，默认左脚
        #Set the offset by accepting whether to hit with the left foot or the right foot. 
        #This version does not use it and defaults to hitting with the left foot
        if shoot_leg == RIGHT_LEG:
            bias_x = -0.2 * multi_bias
            bias_y = 0.08 * multi_bias
        elif shoot_leg == LEFT_LEG:
            bias_x = -0.2 * multi_bias
            bias_y = -0.08 * multi_bias
        else:
            bias_x = -0.2 * multi_bias
            bias_y = 0.08 * multi_bias

        best_pos_x = ball_x + bias_x
        best_pos_y = ball_y + bias_y

        return best_pos_x,best_pos_y

        
    


