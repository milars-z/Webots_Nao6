## For Vision part
## Now use reviever to get the position of ball and robot

from Receiver import receiver
           

class VisionReviewer:
    def __init__(self, nao_robot):
        self.receiver = receiver(nao_robot)

        self.ball_x = None
        self.ball_y = None
        self.robot_x = None
        self.robot_y = None
        self.robot_z = None


    def update(self):

        # 调用函数获取所有数据
        # Call the function to retrieve all data
        ball_x, ball_y, robot_x, robot_y, robot_z= self.receiver.get_all_positions()

        # 如果成功收到了数据包（第一个值不是None就代表成功）
        #If the packet is successfully received (if the first value is not None, it indicates success)
        if ball_x is not None:
            self.ball_x = ball_x
            self.ball_y = ball_y
            self.robot_x = robot_x
            self.robot_y = robot_y
            self.robot_z = robot_z
    def get_ball_position(self):
        
        return self.ball_x, self.ball_y

    def get_robot_position(self):
        
        return self.robot_x, self.robot_y, self.robot_z
