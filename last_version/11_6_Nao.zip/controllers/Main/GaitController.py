import math
import numpy as np
from controller import Motion

class GaitController:

    def __init__(self, Nao):
        self.robot = Nao
        self.time_step = int(self.robot.getBasicTimeStep())
        
        # 内部时钟，用于生成正弦波
        self.time = 0.0

        #初始化flag
        #Initialize flag
        self.currentlyPlaying = None
        self.last_state = None
        self.kick_time = 0
        self.kick_flag = 0
        self.right_time = 0
        self.right_flag = 0
        self.left_time = 0
        self.left_flag = 0

        #预加载motion文件
        #Preloading motion files
        self.motions = {
            'forward': Motion('../../motions/Forwards.motion'),
            'back': Motion("../../motions/Backwards.motion"),
            'turn_left': Motion('../../motions/SideStepLeft.motion'),
            'turn_right': Motion('../../motions/SideStepRight.motion'),
            'kick': Motion('../../motions/Shoot.motion'),
            'StandUp': Motion('../../motions/StandUpFromFront_m.motion') 
        }

        
        #循环控制，这里不设置循环，可删除
        #.setLoop(True)
        #No use
        self.motions['forward']
        self.motions['back']
        self.motions['turn_left']
        self.motions['turn_right']
        self.motions['kick']
        

    def manage_state_(self, new_state):
        
        print(new_state)

        #如果新状态不在selfmotion中，则跳过（错误的输入
        #If the new state is not in self motion, skip (incorrect input) 
        if new_state not in self.motions:
            return
        
        #如果新状态和就状态相同且上一个动作已完成为否，则跳过，不影响当前动作
        #If the new state is the same as the current state and the previous action has been completed, 
        #skip without affecting the current action
        if new_state == self.last_state and not self.currentlyPlaying.isOver() :
            return
        
        #如果上一个动作是踢球，向右或向左，且时间距离现在的时间不到3s，则跳过
        #连续动作可能会让机器人不稳定而摔倒，需改进motion数据
        #If the previous action was kicking a ball, to the right or left, and the time is less than 3 seconds from the current time, then skip it 
        #Continuous movements may cause the robot to become unstable and fall, and motion data needs to be improved
        if self.kick_flag == 1 and ((self.robot.getTime() - self.kick_time) < 3.0):
            return
        else:
            self.kick_flag == 0

        if self.left_flag == 1 and ((self.robot.getTime() - self.left_time) < 3.0):
            return
        else:
            self.left_flag == 0

        if self.right_flag == 1 and ((self.robot.getTime() - self.right_time) < 3.0):
            return
        else:
            self.right_flag == 0

        #再次判断状态是否在motion中，防止出bug（也可以去掉判断
        #此时上一帧动作已经完成
        #Re check if the status is in motion to prevent bugs (or remove the check) 
        #At this point, the previous frame action has been completed
        if new_state in self.motions:
            #更新现在的动作
            #Update current actions
            self.currentlyPlaying = self.motions[new_state]
            #开始现在的动作
            #Start the current action
            self.currentlyPlaying.play()
            #更新上一个动作
            #Update the previous action
            self.last_state = new_state
            #如果上一个动作是踢球向左或向右则刷新flag
            #If the previous action was kicking to the left or right, refresh the flag
            if new_state == 'kick':
                self.kick_time = self.robot.getTime()
                self.kick_flag = 1
            if new_state == 'turn_left':
                self.left_time = self.robot.getTime()
                self.left_flag = 1
            if new_state == 'turn_right':
                self.right_time = self.robot.getTime()
                self.right_flag = 1
                