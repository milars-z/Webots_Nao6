import struct

class receiver:
    def __init__(self,Nao):
        timestep = int(Nao.getBasicTimeStep())
        #设置接收器
        #Set receiver
        self.receiver = Nao.getDevice("robot_receiver")
        if self.receiver is None:
            print("cant find 'robot_receiver'")
        else:
            #成功找到则设置接收器
            #If successfully found, set the receiver
            self.receiver.enable(timestep)
            self.receiver.setChannel(1) 

    def get_all_positions(self):

        if self.receiver.getQueueLength() > 0:
            message = self.receiver.getBytes()
            
            # 解包所有数据
            # Unpack all data
            coords = struct.unpack('ddddd', message)
            
            # 处理完当前消息包
            # Finished processing the current message packet
            self.receiver.nextPacket()
            
            # 将所有解包后的数据返回
            # Return all unpacked data
            ball_x, ball_y = coords[0], coords[1]
            robot_x, robot_y,robot_z = coords[2], coords[3],coords[4]
            return ball_x, ball_y, robot_x, robot_y,robot_z
        
        # 如果没有消息，则返回None
        # If there is no message, return None
        return None, None, None, None,None