from controller import Robot, Keyboard, Motion
from VisionLib import VisionReviewer


#v1.1新增，为后续开发准备
RED_TEAM_FLAG  = -1
BLUE_TEAM_FLAG = 1

#V1.1新增，作为角度容忍值，偏离3.14 +-0.15都是可以接受的，也是转向8度能补偿的最小值
ANGLE_TOLERANCE = 0.15

#V1.1 新增，作为阈值配置指导机器人寻找正确的motion
SIXTY_DEGREEN = 1.2
FORTY_DEGREEN = 0.85

GO_FORWARD = 1
GO_BACK    = 2
TURN_RIGHT = 3
TURN_LEFT  = 4
SHOOT      = 0

DOOR_POS_X = -4.25
DOOR_POS_Y = 0

RIGHT_LEG = 0
LEFT_LEG  = 1
TOLERANCE_X = 0.05
TOLERANCE_Y = 0.1

class Logic:
    
    def __init__(self,Nao):

        #self.reciever = vision_reviever(Nao)
        self.reciever = VisionReviewer(Nao)
        self.timeStep = int(Nao.getBasicTimeStep())
        #V1.1 新增，作为机器人正常配置，保持机器人面朝前方
        self.normal_angle = RED_TEAM_FLAG * 3.14

    def find_state(self):
        door_x    = DOOR_POS_X
        door_y    = DOOR_POS_Y
        tolerance_x = TOLERANCE_X
        tolerance_y = TOLERANCE_Y
        now_state = 'forward'

        self.reciever.update()

        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        #V1.1 新增，每一次查找状态获取一次此时的角度值
        robot_angle = self.reciever.get_robot_angle()

        #print(robot_angle)
        if(robot_z != None ):
            if( robot_z < 0.18 ):
                now_state = 'StandUp'
                return now_state
            
        #V1.1 新增，当现在的角度和正常角度相比大于容忍值则先摆正面向
        #在后续版本中可能会遇到当球在身后，需要向后转的情况，先不予讨论
        if(abs(robot_angle - self.normal_angle) > ANGLE_TOLERANCE ):
            
            #现角度大于正常角度，机器人偏左，右转
            if( robot_angle > self.normal_angle ):
                #偏差角极大超过60度
                if( robot_angle - self.normal_angle > SIXTY_DEGREEN ):
                    now_state = 'turn_right_60'
                    #偏差角大于40度
                elif (robot_angle - self.normal_angle > FORTY_DEGREEN):
                        now_state = 'turn_right_40'
                #存在偏差角
                else: now_state = 'turn_right_08'
            #现角度小于正常角度，机器人偏右，左转
            else:
                if( robot_angle - self.normal_angle < SIXTY_DEGREEN ):
                    now_state = 'turn_left_80'
                    #偏差角大于40度
                elif (robot_angle - self.normal_angle < FORTY_DEGREEN):
                        now_state = 'turn_left_40'
                #存在偏差角
                else: now_state = 'turn_left_08'

            #出现偏移现象优先调整朝向
            print(now_state)
            return now_state


        if( (ball_x != None) & (ball_y != None )):
            best_pos_x,best_pos_y = self.find_best_shoot_place(ball_x,ball_y,LEFT_LEG)
            if( abs((door_x - best_pos_x) - (door_x - robot_x)) > tolerance_x ):
                
                if ((door_x - best_pos_x) > (door_x - robot_x)):
                    now_state = 'forward'
                elif ((door_x - best_pos_x) < (door_x - robot_x)):
                    now_state = 'back'

            elif((robot_y - ball_y) < 0.0):
                now_state = 'turn_right'
            elif((robot_y - ball_y) > 0.12):
                now_state = 'turn_left'

            else:
                now_state = 'kick'

        return now_state
    


    def find_best_shoot_place(self,ball_x,ball_y,shoot_leg):
        
        #接受球门的位置，y轴位置后期会在计算角度时用到
        #Accept the position of the goal, and the y-axis position will be used in calculating the angle later on
        door_x = DOOR_POS_X
        door_y = DOOR_POS_Y 

        # multi_bias
        #区分球门的左右位置
        #Distinguish the left and right positions of the goal
        if( door_x > 0 ):
            multi_bias =  1
        else: 
            multi_bias = -1

        #通过接受用左脚击球还是右脚击球来设置偏移，该版本没用到，默认左脚
        #Set the offset by accepting whether to hit with the left foot or the right foot. 
        #This version does not use it and defaults to hitting with the left foot
        if shoot_leg == RIGHT_LEG:
            bias_x = -0.2 * multi_bias
            bias_y = 0.06 * multi_bias
        elif shoot_leg == LEFT_LEG:
            bias_x = -0.2 * multi_bias
            bias_y = -0.06 * multi_bias
        else:
            bias_x = -0.2 * multi_bias
            bias_y = 0.06 * multi_bias

        best_pos_x = ball_x + bias_x
        best_pos_y = ball_y + bias_y

        return best_pos_x,best_pos_y

        
    


