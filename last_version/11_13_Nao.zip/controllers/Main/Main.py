from controller import Robot

from GaitController import GaitController
from LogicLib import Logic
from PosrLib import PoseLib

NAO6_robot = Robot()
timestep = int(NAO6_robot.getBasicTimeStep())

class Robot():
    
    def __init__(self,NAO6_robot):

        #步态库
        #Gait Library
        self.gait_ctrl   = GaitController(NAO6_robot)
        #逻辑库
        #Logical Library
        self.Nao_logic   = Logic(NAO6_robot)

        self.Pos = PoseLib(NAO6_robot)


        
        #设置模拟时间
        #Set simulation time
        total_time = 300  # in seconds
        steps_per_second = int(1000 / timestep)
        self.total_steps = total_time * steps_per_second
        
    def run(self):
        
        current_step = 0
        self.Pos.stand_up()
        while (NAO6_robot.step(timestep) != -1)&(current_step <self.total_steps) :

            #更新现在的模拟时间
            #Update the current simulation time
            current_simulation_time = NAO6_robot.getTime()
            current_step = int(current_simulation_time*1000/timestep)
            
            #查找现在的状态
            #Find the current status
            state = self.Nao_logic.find_state()

            #根据现在的状态选择步态
            #Choose a gait based on the current state
            self.gait_ctrl.manage_state_(state)
            

Robot = Robot(NAO6_robot)
Robot.run()