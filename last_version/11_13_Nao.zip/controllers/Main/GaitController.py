import math
import numpy as np
from controller import Motion

class GaitController:

    def __init__(self, Nao):
        self.robot = Nao
        self.time_step = int(self.robot.getBasicTimeStep())
        
        # 内部时钟，用于生成正弦波
        self.time = 0.0

        #初始化flag
        #Initialize flag
        #V1.1新增所有motion的flag
        #后续此部分需要更新，用输出存储状态比较简洁
        self.currentlyPlaying = None
        self.last_state = None
        self.kick_time = 0
        self.kick_flag = 0
        self.right_time = 0
        self.right_flag = 0
        self.left_time = 0
        self.left_flag = 0
        self.walk_time = 0
        self.walk_flag = 0  
        self.standup_time = 0
        self.standup_flag = 0  
        self.back_time = 0
        self.back_flag = 0
        self.left08_time = 0
        self.left08_flag = 0 
        self.left40_time = 0
        self.left40_flag = 0
        self.left60_time = 0
        self.left60_flag = 0
        self.right08_time = 0
        self.right08_flag = 0 
        self.right40_time = 0
        self.right40_flag = 0
        self.right60_time = 0
        self.right60_flag = 0  
   
        self.now_motion_start = False


        #V1.1更新旋转运动的motion路径
        self.motions = {
            'forward': Motion('../../motions/Forwards.motion'),
            'back': Motion("../../motions/Backwards.motion"),
            'turn_left': Motion('../../motions/SideStepLeft.motion'),
            'turn_right': Motion('../../motions/SideStepRight.motion'),
            'kick': Motion('../../motions/fast_shoot.motion'),
            'StandUp': Motion('../../motions/StandUpFromFront_m.motion'),
            'turn_left_08':Motion('../../motions/TurnLeft08.motion'),
            'turn_left_40': Motion('../../motions/TurnLeft40.motion'),
            'turn_left_60': Motion('../../motions/TurnLeft60.motion'),
            'turn_right_08': Motion('../../motions/TurnRight08.motion'),
            'turn_right_40': Motion('../../motions/TurnRight40.motion'),
            'turn_right_60': Motion('../../motions/TurnRight60.motion'),
        }

        
        #V1.1 此处仍未使用，可删除，放着也不影响
        #循环控制，这里不设置循环，可删除
        #.setLoop(True)
        #No use
        self.motions['forward'].setLoop(False)
        self.motions['back'].setLoop(False)
        self.motions['turn_left'].setLoop(False)
        self.motions['turn_right'].setLoop(False)
        self.motions['kick'].setLoop(False)
        
        #V1.1更新，用来设置state
        self.Init = 0
        self.InputCheck = 1
        self.FlagCheck = 2
        self.NewmotionCheck = 3
        self.PlayNewMotion = 4
        self.fist_run = True

    #V1.1 主要更新点，更新了state轮换的逻辑减少相关bug
    def manage_state_(self, new_state):

        input_state = self.Init
        
        #排除错误输入
        if new_state not in self.motions:
            return
        else:
            input_state = self.InputCheck

        #动作后停顿 确保当前动作结束
        if input_state == self.InputCheck:
            check_flags = self.check_flags()
            if check_flags:
                input_state = self.FlagCheck
            else:
                return
        
        #确认下一帧是否是新动作
        if input_state == self.FlagCheck:
            if new_state == self.last_state:
                input_state = self.NewmotionCheck
            else:
                input_state = self.NewmotionCheck


        if input_state == self.NewmotionCheck or self.fist_run:
            self.fist_run = False
            print("Changing state to:", new_state)
            self.currentlyPlaying = self.motions[new_state]
            self.currentlyPlaying.play()
            self.last_state = new_state
            self.now_motion_start = True

            #V1.1 此处flag设置的操作后续也需要更新成数组异或操作
            if new_state == 'kick':
                print("kick")
                self.kick_time = self.robot.getTime()
                self.kick_flag = 1
            elif new_state == 'forward':
                print("gogogo")
                self.walk_time = self.robot.getTime()
                self.walk_flag = 1
            elif new_state == 'turn_left':
                print("turn left")
                self.left_time = self.robot.getTime()
                self.left_flag = 1
            elif new_state == 'turn_right':
                print("turn right")
                self.right_time = self.robot.getTime()
                self.right_flag = 1
            elif new_state == 'StandUp':
                print("stand up")
                self.standup_time = self.robot.getTime()
                self.standup_flag = 1
            elif new_state == 'back':
                print("back")
                self.back_time = self.robot.getTime()
                self.back_flag = 1
            elif new_state == 'turn_left_08':
                print("turn_left_08")
                self.left08_time = self.robot.getTime()
                self.left08_flag = 1
            elif new_state == 'turn_left_40':
                print("turn_left_40")
                self.left40_time = self.robot.getTime()
                self.left40_flag = 1
            elif new_state == 'turn_left_60':
                print("turn_left_60")
                self.left60_time = self.robot.getTime()
                self.left60_flag = 1
            elif new_state == 'turn_right_08':
                print("turn_right_08")
                self.right08_time = self.robot.getTime()
                self.right08_flag = 1
            elif new_state == 'turn_right_40':
                print("turn_right_40")
                self.right40_time = self.robot.getTime()
                self.right40_flag = 1
            elif new_state == 'turn_right_60':
                print("turn_right_60")
                self.right60_time = self.robot.getTime()
                self.right60_flag = 1
                
    #V1.1更新，flag检查
    #具体时间配置见motion文件
    #后续需修改
    def check_flags(self):
        if self.kick_flag == 1 and ((self.robot.getTime() - self.kick_time) < 3.6):
            return 0
        else:
            self.kick_flag = 0 

        if self.left_flag == 1 and ((self.robot.getTime() - self.left_time) < 4.96):
            return 0
        else:
            self.left_flag = 0 

        if self.right_flag == 1 and ((self.robot.getTime() - self.right_time) < 5.76):
            return 0
        else:
            self.right_flag = 0 
        
        if self.walk_flag == 1 and ((self.robot.getTime() - self.walk_time) < 2.6):
            return 0
        else:
            self.walk_flag = 0
                
        if self.standup_flag == 1 and ((self.robot.getTime() - self.standup_time) < 5.0):
            return 0
        else:
            self.standup_flag = 0
        
        if self.back_flag == 1 and ((self.robot.getTime() - self.back_time) < 2.6):
            return 0
        else:
            self.back_flag = 0
        #left_08
        if self.left08_flag == 1 and ((self.robot.getTime() - self.left08_time) < 1.56):
            return 0
        else:
            self.left08_flag = 0
        #left_40
        if self.left40_flag == 1 and ((self.robot.getTime() - self.left40_time) < 2.88):
            return 0
        else:
            self.left40_flag = 0
        #left_60
        if self.left60_flag == 1 and ((self.robot.getTime() - self.left60_time) < 4.52):
            return 0
        else:
            self.left60_flag = 0
        #right_08
        if self.right08_flag == 1 and ((self.robot.getTime() - self.right08_time) < 1.56):
            return 0
        else:
            self.right08_flag = 0
        #right_40
        if self.right40_flag == 1 and ((self.robot.getTime() - self.right40_time) < 2.88):
            return 0
        else:
            self.right40_flag = 0
        #right_60
        if self.right60_flag == 1 and ((self.robot.getTime() - self.right60_time) < 4.56):
            return 0
        else:
            self.right60_flag = 0
        
            

        if ((self.kick_flag == 0) and
            (self.left_flag == 0) and 
            (self.right_flag == 0) and
            (self.walk_flag == 0) and
            (self.standup_flag == 0) and
            (self.back_flag == 0) and
            (self.left08_flag == 0) and
            (self.left40_flag == 0) and
            (self.left60_flag == 0) and
            (self.right08_flag == 0) and
            (self.right40_flag == 0) and
            (self.right60_flag == 0) ):
            return 1