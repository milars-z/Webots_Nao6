## For Vision part
## Now use reviever to get the position of ball and robot

from Receiver import receiver
           

class VisionReviewer:
    def __init__(self, Nao):
        timestep = int(Nao.getBasicTimeStep())

        self.receiver = receiver(Nao)

        self.ball_x = None
        self.ball_y = None
        self.robot_x = None
        self.robot_y = None
        self.robot_z = None

        #V1.1 新增角度控制相关，处理角度突变
        

        #V1.1新增，控制角度
        #不依赖supervisor，但是为了整洁放在这里
        self.iu = Nao.getDevice("inertial_unit")
        self.iu.enable(timestep)

        roll_pitch_yaw = self.iu.getRollPitchYaw()
        yaw = roll_pitch_yaw[2] 
        self.old_yaw  = yaw

    def update(self):

        # 调用函数获取所有数据
        # Call the function to retrieve all data
        ball_x, ball_y, robot_x, robot_y, robot_z= self.receiver.get_all_positions()

        # 如果成功收到了数据包（第一个值不是None就代表成功）
        #If the packet is successfully received (if the first value is not None, it indicates success)
        if ball_x is not None:
            self.ball_x = ball_x
            self.ball_y = ball_y
            self.robot_x = robot_x
            self.robot_y = robot_y
            self.robot_z = robot_z



    def get_ball_position(self):
        
        return self.ball_x, self.ball_y

    def get_robot_position(self):
        
        return self.robot_x, self.robot_y, self.robot_z
    
    #V1.1新增，用来返回angle
    def get_robot_angle(self):
        roll_pitch_yaw = self.iu.getRollPitchYaw()
        yaw = roll_pitch_yaw[2] 
        if( abs(yaw - self.old_yaw) > 5.5):
            yaw = yaw * -1
            self.old_yaw = yaw
        else:
             self.old_yaw = yaw
        return yaw
        
    
