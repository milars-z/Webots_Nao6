from controller import Supervisor
import struct 



#初始化 Supervisor
#Initialize Supervisor
supervisor = Supervisor()
timestep = int(supervisor.getBasicTimeStep())

# 获取球节点
# Obtain ball nodes
ball_name = "BALL"
ball_node = supervisor.getFromDef(ball_name)
if ball_node is None:
    print(f"cant find {ball_name}")

# 获取机器人节点
# Obtain robot nodes
robot_def_name = "Robot"  
robot_node = supervisor.getFromDef(robot_def_name)

# 检查是否成功找到了节点
# Check if the node has been successfully found
if robot_node is None:
    print(f"无法找到 '{robot_def_name}' ")



# 获取 Emitter 设备
# Obtain the emitter device
emitter = supervisor.getDevice("supervisor_emitter")
if emitter is None:
    print("cant find'supervisor_emitter'!")
else:
    #找到后设置channel为1
    #Set the channel to 1 after finding it
    emitter.setChannel(1) 

while supervisor.step(timestep) != -1:
    if ball_node and robot_node and emitter:
        #获取球的实时位置
        #Obtain the real-time position of the ball
        ball_position = ball_node.getPosition()
        robot_position = robot_node.getPosition()
        ball_x, ball_y = ball_position[0], ball_position[1]
        robot_x, robot_y ,robot_z= robot_position[0], robot_position[1],robot_position[2]
        # 将坐标数据打包成字节流 (bytes)
        #Package coordinate data into byte streams (bytes)
        message = struct.pack('ddddd', ball_x, ball_y,robot_x,robot_y,robot_z)
        
        # 通过 Emitter 发送消息
        # Send a message through the emitter
        emitter.send(message)