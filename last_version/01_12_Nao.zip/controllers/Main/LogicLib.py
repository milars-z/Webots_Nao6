from controller import Robot, Keyboard, Motion
from VisionLib import VisionReviewer


#v1.1新增，为后续开发准备
RED_TEAM_FLAG  = -1
BLUE_TEAM_FLAG = 1

#V1.1新增，作为角度容忍值，偏离3.14 +-0.15都是可以接受的，也是转向8度能补偿的最小值
ANGLE_TOLERANCE = 0.15

#V1.1 新增，作为阈值配置指导机器人寻找正确的motion
SIXTY_DEGREEN = 1.2
FORTY_DEGREEN = 0.85

GO_FORWARD = 1
GO_BACK    = 2
TURN_RIGHT = 3
TURN_LEFT  = 4
SHOOT      = 0

DOOR_POS_X = -4.25
DOOR_POS_Y = 0

RIGHT_LEG = 0
LEFT_LEG  = 1
#最后一帧留给stop，需要提前停止，滑动窗口计算距离，需要增加值
TOLERANCE_X = 0.07
TOLERANCE_Y = 0.0225

class Logic:
    
    def __init__(self,Nao):

        #V1.2 新增获取机器人名字决定队伍
        self.name = Nao.getName()
        self.reciever = VisionReviewer(Nao)
        self.timeStep = int(Nao.getBasicTimeStep())
        #V1.1 新增，作为机器人正常配置，保持机器人面朝前方
        self.normal_angle = RED_TEAM_FLAG * 3.14

        #存储上一次的状态，用来循环右移左移
        self.last_state = None

    def find_state(self):
        door_x    = DOOR_POS_X
        door_y    = DOOR_POS_Y
        tolerance_x = TOLERANCE_X
        tolerance_y = TOLERANCE_Y
        now_state = 'Hand_Wave'

        self.reciever.update()

        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        robot_angle = self.reciever.get_robot_angle()
        flag = self.reciever.get_flag()

        #print(robot_angle)
        if(robot_z != None ):
            if( robot_z < 0.18 ):
                now_state = 'StandUp'
                return now_state
            
        if flag == 1 or flag == 2:
            now_state = 'Hand_Wave'
            return now_state

        if(abs(robot_angle - self.normal_angle) > ANGLE_TOLERANCE ):
            
            #现角度大于正常角度，机器人偏左，右转
            if( robot_angle > self.normal_angle ):
                #偏差角极大超过60度
                if( robot_angle - self.normal_angle > SIXTY_DEGREEN ):
                    now_state = 'turn_right_60'
                    #偏差角大于40度
                elif (robot_angle - self.normal_angle > FORTY_DEGREEN):
                        now_state = 'turn_right_40'
                #存在偏差角
                else: now_state = 'turn_right_08'
            #现角度小于正常角度，机器人偏右，左转
            else:
                if( robot_angle - self.normal_angle < SIXTY_DEGREEN ):
                    now_state = 'turn_left_80'
                    #偏差角大于40度
                elif (robot_angle - self.normal_angle < FORTY_DEGREEN):
                        now_state = 'turn_left_40'
                #存在偏差角
                else: now_state = 'turn_left_08'

            #出现偏移现象优先调整朝向
            return now_state

        if( (ball_x != None) & (ball_y != None )):
            best_pos_x,best_pos_y = self.find_best_shoot_place(ball_x,ball_y,LEFT_LEG)
            if( abs((door_x - best_pos_x) - (door_x - robot_x)) > tolerance_x ):
                
                if ((door_x - best_pos_x) > (door_x - robot_x)):
                    now_state = 'forward'
                elif ((door_x - best_pos_x) < (door_x - robot_x)):
                    now_state = 'back'

            
            elif((robot_y - ball_y) < 0):
                now_state = 'turn_right'
            elif((robot_y - ball_y) > 0.08):
                now_state = 'turn_left'

            else:
                now_state = 'kick'

        return now_state
    


    def find_best_shoot_place(self,ball_x,ball_y,shoot_leg):
        
        door_x = DOOR_POS_X
        door_y = DOOR_POS_Y 

        if( door_x > 0 ):
            multi_bias =  1
        else: 
            multi_bias = -1

        if shoot_leg == RIGHT_LEG:
            bias_x = -0.215 * multi_bias
            bias_y = 0.0725 * multi_bias
        elif shoot_leg == LEFT_LEG:
            bias_x = -0.215 * multi_bias
            bias_y = -0.0725 * multi_bias
        else:
            bias_x = -0.215 * multi_bias
            bias_y = 0.0725 * multi_bias

        best_pos_x = ball_x + bias_x
        best_pos_y = ball_y + bias_y

        return best_pos_x,best_pos_y
    

    #击球手力度太低，守门员只用左右移动
    def get_state_keeper(self):

        self.reciever.update()
        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        robot_angle = self.reciever.get_robot_angle()

        now_state = 'Hand_Wave'

        if(robot_y != None ):
            if((robot_y - ball_y) < 0.0):
                now_state = 'turn_left'
            elif((robot_y - ball_y) > 0.12):
                now_state = 'turn_right'

        return now_state
    
    #击球手力度太低，守门员只用左右移动
    def get_state_defender(self):

        
        self.reciever.update()
        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        robot_angle = self.reciever.get_robot_angle()

        now_state = 'Hand_Wave'

        #根据命名设置不同的门的位置
        if self.name == 'Red_Defender_1' or self.name == 'Red_Defender_2':
            Door_x = 4.5
        if self.name == 'Black_Defender_1' or self.name == 'Black_Defender_2':
            Door_x = -4.5
        else: print("wrong funciton")

        #根据1/2控制不同的逻辑（1为激进防御手，2为控球防御手）
        if self.name == 'Red_Defender_1' or self.name == 'Black_Defender_1':
            now_state = 'Hand_Wave'



        return now_state


    #下面的逻辑更新完成一个目的，让机器人在前方有人时能够绕开踢球

    #由于现在最好只能直击，因此在每次击球前考虑，球与进球点之间有没有人
    #如果没有人，则执行kick逻辑，且目标点设置为进球点
    #如果有人，则重设一个进球点，（pos_x,pos_y+1）
    #即让机器人将球往右踢一点(一直加直到确认击球线中没人)
    

    # 如何判断进球
    # 球的坐标x<-4.5 或x>4.5  且 0.8>y>-0.8

    # 如何判断球达到传球点位置
    # 球和传球点的距离小于Tolerance，或(ball_y-robot_y) > (pos_y-robot_y)
    # 如果判断达到传球点，则讲传球点设置为进球点

    # 由于机器人每一次walk都是朝向进球点(传球点)
    # 如果方向是正确的话，每一次walk_loop后，x轴的距离都会减少一个范围
    # 如果减少的范围小于设定的值，则此时可能方向错了
    # 根据少走的值判断该旋转多少度
    # 根据y轴的偏移考虑改左转还是右转

    # 假设每走一步对x轴的贡献值为 k
    # 当前loop的贡献值为 n
    # if (n<k): 需要调整方向
    # elif (n < 0) :走反了
        
    


