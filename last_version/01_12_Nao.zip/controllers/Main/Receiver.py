import struct

class receiver:
    def __init__(self,Nao):
        timestep = int(Nao.getBasicTimeStep())
        #设置接收器
        #Set receiver
        self.receiver = Nao.getDevice("robot_receiver")
        self.robot_name  = Nao.getName() 
        if self.receiver is None:
            print("cant find 'robot_receiver'")
        else:
            #成功找到则设置接收器
            #If successfully found, set the receiver
            self.receiver.enable(timestep)
            if(self.robot_name == 'Black_Striker' or
               self.robot_name == 'Black_Defender_1' or
               self.robot_name == 'Black_Defender_2' or
               self.robot_name == 'Black_Keeper'):
                self.receiver.setChannel(1) 
            if(self.robot_name == 'Red_Striker' or
               self.robot_name == 'Red_Defender_1' or
               self.robot_name == 'Red_Defender_2' or
               self.robot_name == 'Red_Keeper'):
                self.receiver.setChannel(1) 

    #V1.2修改，处理了发送的数据无法及时接受的bug
    def get_all_positions(self):

        latest_message = None

        while self.receiver.getQueueLength() > 0:
            latest_message = self.receiver.getBytes()
            self.receiver.nextPacket()

        if latest_message is not None:
            try:
                count = len(latest_message) // 8
                
                coords = struct.unpack('d' * count , latest_message)
                ball_x, ball_y = coords[0], coords[1]
                if (self.robot_name == 'Black_Striker'):
                    robot_x, robot_y, robot_z = coords[2], coords[3], coords[4]
                elif (self.robot_name == 'Red_Striker'):
                    robot_x, robot_y, robot_z = coords[5], coords[6], coords[7]
                elif (self.robot_name == 'Black_Defender_1'):
                    robot_x, robot_y, robot_z = coords[8], coords[9], coords[10]
                elif (self.robot_name == 'Red_Defender_1'):
                    robot_x, robot_y, robot_z = coords[11], coords[12], coords[13]
                elif (self.robot_name == 'Black_Defender_2'):
                    robot_x, robot_y, robot_z = coords[14], coords[15], coords[16]
                elif (self.robot_name == 'Red_Defender_2'):
                    robot_x, robot_y, robot_z = coords[17], coords[18], coords[19]
                elif (self.robot_name == 'Black_Keeper'):
                    robot_x, robot_y, robot_z = coords[20], coords[21], coords[22]
                elif (self.robot_name == 'Red_Keeper'):
                    robot_x, robot_y, robot_z = coords[23], coords[24], coords[25]

                flag = coords[26]

                return ball_x, ball_y, robot_x, robot_y, robot_z, flag
            except struct.error:
                print("Received data size mismatch.")
                return None, None, None, None, None, None
        return None, None, None, None, None, None
    
