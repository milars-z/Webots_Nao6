from controller import Robot, Keyboard, Motion
from VisionLib import VisionReviewer
import math


#v1.1新增，为后续开发准备
RED_TEAM_FLAG  = -1
BLUE_TEAM_FLAG = 1

#V1.1新增，作为角度容忍值，偏离3.14 +-0.15都是可以接受的，也是转向8度能补偿的最小值
ANGLE_TOLERANCE = 0.20

#V1.4新增，最大角度容忍，避免机器人在斜线行走过程中频繁改变角度,大概40度
ANGLE_TOLERANCE_MAX = 0.6

#V1.1 新增，作为阈值配置指导机器人寻找正确的motion
BIG_DEGREEN   = 2.5
SIXTY_DEGREEN = 1.2
FORTY_DEGREEN = 0.75


GO_FORWARD = 1
GO_BACK    = 2
TURN_RIGHT = 3
TURN_LEFT  = 4
SHOOT      = 0

DOOR_POS_X_B = -4.25
DOOR_POS_X_R = 4.25
DOOR_POS_Y_B = 0
DOOR_POS_Y_R = 0

RIGHT_LEG = 0
LEFT_LEG  = 1
#最后一帧留给stop，需要提前停止，滑动窗口计算距离，需要增加值
OFFSET_X_BACK = 0.065
OFFSET_X_FRONT = 0.07
OFFSET_Y_LEFT = 0.018
OFFSET_Y_RIGHT = 0.030


class Logic:
    
    def __init__(self,Nao):

        #V1.2 新增获取机器人名字决定队伍
        self.name = Nao.getName()
        self.visionReviewer = VisionReviewer(Nao)
        self.timeStep = int(Nao.getBasicTimeStep())
        #V1.1 新增，作为机器人正常配置，保持机器人面朝前方
        self.normal_angle = RED_TEAM_FLAG * 3.14

        #存储上一次的状态，用来循环右移左移
        self.last_state = None

        #存储上一次踢球前球的位置，用来判断球是否提到了
        self.last_ball_x = None
        self.last_ball_y = None
        self.kick_adjust_count = 0

        team = 'Black'
        if team == 'Black':
            self.door_x = DOOR_POS_X_B
            self.door_y = DOOR_POS_Y_B
            self.team = 'Black'
        else:
            self.door_x = DOOR_POS_X_R
            self.door_y = DOOR_POS_Y_R
            self.team = 'Red'

        #传球判断相关
        self.passball_pos = {
            'goal_center':(-4.5,0),
            'goal_left':(-4.5,-1),
            'goal_right':(-4.5,1),
            'mid_left':(-3.25,-1.5),
            'mid_right':(-3.25,1.5),
            'back_left':(-2.25,-1.5),
            'back_right':(-2.25,1.5),
            'abandon':(4.5,-3)
        }

        self.priority_list = ['goal_center', 
                              'goal_left', 'goal_right', 
                              'mid_left', 'mid_right',
                              'back_left', 'back_right',
                              'abandon']
        #状态flag
        self.back_state_flag = 0

        #状态树整体状态flag
        self.state_tree_index = 0

        #阻挡判断相关
        self.obstacle_threshold = 0.25

        #左右移动和向左转后前进的判断
        #当小球在机器人的左右两侧超过1m，则不用左右移动来调整位置
        #直接左右转再前进
        self.side_threshold = 1

        #转向后移动和直接倒退的判断
        #当小球在机器人后方超过一定距离后机器人调头在走向目标点
        self.back_threshold = 1

        #保持球在机器人前方至少0.15m的距离
        self.mindis_ball_robot = 0.15

        #保持机器人与球的横向水平距离大于0.2，以防倒推碰到球
        self.mindis_ball_robot_side = 0.2

        #精细踢球半径
        self.accu_kick_threshold = 0.6

    def find_state(self):

        now_state = 'Hand_Wave'

        self.visionReviewer.update(self.name)

        robot_x,robot_y,robot_z = self.visionReviewer.get_robot_position()
        ball_x,ball_y = self.visionReviewer.get_ball_position()
        robot_angle = self.visionReviewer.get_robot_angle()
        flag = self.visionReviewer.get_flag()

        #print(robot_angle)
        if(robot_z != None ):
            if( robot_z < 0.18 ):
                now_state = 'StandUp'
                return now_state
            
        if flag == 1 or flag == 2:
            now_state = 'Hand_Wave'
            return now_state

        #V1.4新增用来应对角度突变情况
        if (abs(robot_angle - self.normal_angle)) > (abs(robot_angle - (-1 * self.normal_angle))):
            normal_angle = -1.0 * self.normal_angle

        else:
            normal_angle = self.normal_angle

        if(abs(robot_angle - normal_angle) > ANGLE_TOLERANCE ):
            
            #现角度大于正常角度，机器人偏左，右转
            if( robot_angle > normal_angle ):
                #偏差角极大超过60度
                if( robot_angle - normal_angle > SIXTY_DEGREEN ):
                    now_state = 'turn_right_60'
                    #偏差角大于40度
                elif (robot_angle - normal_angle > FORTY_DEGREEN):
                        now_state = 'turn_right_40'
                #存在偏差角
                else: now_state = 'turn_right_08'
            #现角度小于正常角度，机器人偏右，左转
            else:
                if( robot_angle - normal_angle < -SIXTY_DEGREEN ):
                    now_state = 'turn_left_60'
                    #偏差角大于40度
                elif (robot_angle - normal_angle < -FORTY_DEGREEN):
                        now_state = 'turn_left_40'
                #存在偏差角
                else: now_state = 'turn_left_08'

            #出现偏移现象优先调整朝向
            return now_state

        if ball_x is not None and ball_y is not None:
            #best_pos_x, best_pos_y = self.find_best_shoot_place(ball_x, ball_y, LEFT_LEG)
            best_pos_x, best_pos_y = self.find_the_best_kick_place(ball_x, ball_y, -2.25, 1.5)
            
            dist_robot_to_door = abs(self.door_x - robot_x)
            dist_target_to_door = abs(self.door_x - best_pos_x)

            error_x = dist_robot_to_door - dist_target_to_door

            error_y = robot_y - best_pos_y

            if error_x > OFFSET_X_BACK:     
                now_state = 'forward'
            elif error_x < -OFFSET_X_FRONT: 
                now_state = 'back'

            elif error_y > OFFSET_Y_LEFT:
                now_state = 'turn_left'      
            elif error_y < -OFFSET_Y_RIGHT:
                now_state = 'turn_right'

            else:
                now_state = 'kickl'
        pd = self.check_obstacle_in_path()
        if(pd == True):
            posx,posy = self.update_door_position()


        return now_state
    
    #V1.4 新增状态树函数
    #该函数代替过去findstate函数,整合更复杂的逻辑
    #状态流程如下：
    #1--检查机器人是否倒地，倒地则站起
    #2--检查当前球的位置与球门间是否有障碍物遮挡
    #3--检查机器人与最佳击球点的位置关系，规划路径并击球
    def state_tree(self):

        aim_x = self.door_x
        aim_y = self.door_y

        fall_state = self.check_robot_fall()

        if fall_state == True:
            return 'StandUp'
        else :
            obstacle_state = self.check_obstacle_in_path()
            #如果有障碍，则更新球门的位置（aim_position）
            if obstacle_state == True:
                aim_x, aim_y = self.update_door_position()
            else:
                pass
            #根据更新后的目标点规划路径
            #参照过去findstate代码
            path_state = self.plan_path_to_ball(aim_x, aim_y)
            return path_state
        
    def check_robot_fall(self):
        self.visionReviewer.update(self.name)
        robot_x,robot_y,robot_z = self.visionReviewer.get_robot_position()
        if(robot_z != None ):
            if( robot_z < 0.18 ):
                return True
        return False
    

    def check_obstacle_in_path(self):

        #检测并返回小球到球门路径上是否有障碍物
        return self.visionReviewer.check_obstacle(self.team,self.door_x,self.door_y,self.obstacle_threshold)
    
    def update_door_position(self):

        #待完成
        #后期可能会作为传球函数
        #现阶段暂时通过给机器人一个角度然后进行踢球
        #初始配置几个击球点循环？代码发展后作为传球函数可复用性高
        #或者说直接配置角度踢球，随缘绕过障碍物？可复用性低
        #如何做角度球？
        #扩大可击球点的距离
        for target_name in self.priority_list:
            target_pos = self.passball_pos[target_name]
            if self.team == 'Red' : 
                target_pos[0] = -target_pos[0]
                target_pos[1] = -target_pos[1]
            if self.visionReviewer.check_obstacle(self.team,target_pos[0],target_pos[1],self.obstacle_threshold) == False:
                #print('change new aim pos:',target_name)
                return target_pos[0],target_pos[1]
            
        #当遍历所有可选点都没有可以传球的位置的时候就没招了，返回最后一个点abandon硬踢，一般不会出现这种情况
        print('no way , check list!')
        return target_pos[0],target_pos[1]

      

        return 0
    
    def plan_path_to_ball(self,aim_x,aim_y):
        #到球的距离多大？
        #优先判断球是不是在自己身后
        #如果小于dis，则优先确定朝向，再左右移动（判断左右脚），再前后移动踢球
        #如果大于dis，则优先缩小距离，如果y轴差过大，先右转左转90度直行，再回转直行
        #如果y轴差在可接受范围内，则左右挪动
        #在距离小于dis阶段报错前后左右面向，即0，90，180，270

        #朝向通过连线的延长线与x轴的距离求，得到角度deg
        #转动角度，判断球偏向左脚还是右脚，计算跨步方向，进行跨步，判断是否能踢到球，不能踢到则向前移动、

        #此处fielse过多，需后续再整理，确保return覆盖每一个分支，每一个if都有else
        #后续调整方向，确保该函数仅有一个return

        #后续应该也要分几个函数，写了个后退就快50行了
        
        #默认值，防止返回空状态
        state = 'Hand_Wave'

        if self.team == 'Black':
            door_pos_x = DOOR_POS_X_B
            normal_angle = 3.14
            back_angle = 0
        else : 
            door_pos_x = DOOR_POS_X_R
            normal_angle = 0
            back_angle = 3.14

        robot_x,robot_y,robot_z = self.visionReviewer.get_robot_position()
        ball_x,ball_y = self.visionReviewer.get_ball_position()
        robot_angle = self.visionReviewer.get_robot_angle()


        if (ball_x is None) or (robot_x is None):
            state = 'Hand_Wave'
            return state
        

        #如果球在后方
        #新问题，如果在多次判断的过程中，球在自己身后但是面向不是朝前怎么做？
        if (abs(ball_x - door_pos_x) - abs(robot_x - door_pos_x ) > -self.mindis_ball_robot):
            #更新状态1
            self.state_tree_index = 1
            #球在后方但是不远处
            if abs(ball_x - robot_x) < self.back_threshold and self.back_state_flag !=1:
                #新增面向判断
                if self.check_angle(robot_angle,normal_angle,ANGLE_TOLERANCE) == False:
                        state = self.change_angle_state(robot_angle,normal_angle)
                        return state
                #判断机器人后退会不会碰到球，保证机器人与球之间在横向有0.2m的距离差
                if abs(ball_y - robot_y) > self.mindis_ball_robot_side :
                    #如果距离比较大不会影响则直接倒推
                    state = 'back'
                    return state
                else:
                    #如果距离较小则根据两者方位向左向右移动
                    if(ball_y > robot_y):
                        state = 'turn_left'
                        return state
                    else:
                        state = 'turn_right'
                        return state
            #球在后方远处
            else:
                #先转向
                #如果机器人的方位和标准方位差小于一定值（判断转向是成功的）则进入下一届段，否则微调
                #直行
                self.back_state_flag = 1
                if self.check_angle(robot_angle,back_angle,ANGLE_TOLERANCE) == False:
                    state = self.change_angle_state(robot_angle,back_angle)
                    return state
                else:
                    state = 'forward'
                    return state

        #此处已经确定了球在后方，但是可能角度会受到影响，因此在这里需要确定角度
        #但是这里不能进行微调，pass算了
        else:
            #当判断球不在自己后方的时候更新状态
            print("完成阶段1")
            self.state_tree_index = 2
            self.back_state_flag = 0

        #第一个判断主要确保球在自身前方，但是方向可能有问题，这里先检查方向
        #仅在刚进行完倒退动作后触发这次修正
        if self.state_tree_index == 1:
            if self.check_angle(robot_angle,normal_angle,ANGLE_TOLERANCE) == False:
                #提前判断下距离
                dis = math.sqrt((robot_x - ball_x)**2 + (robot_y - ball_y)**2)
                if dis >self.side_threshold:
                    if ball_y > robot_y:
                    #魔法数后续需修改
                        aim_angle = 1.57 
                    else:
                        aim_angle = -1.57
                state = self.change_angle_state(robot_angle,aim_angle)
                return state
            else:
                print("完成阶段1")
                self.state_tree_index = 2
                print("角度正确,进行下一阶段")

        

        #--------------------------------------------
        #--------判断阶段2----------------------------
        #--------------------------------------------
        #这个阶段需要根据与球之间的距离来决定后续方向
        #往后转的过程中，如果发现球离自己很远，有需要转回来半圈，很抽象，需要提前判断距离
        #已提前判断距离，现在转向正确
        #首先缩短自己到球的距离
        if self.state_tree_index == 2:
            #重新获取距离
            dis = math.sqrt((robot_x - ball_x)**2 + (robot_y - ball_y)**2)
            # 废案
            # #如果距离过远，此时应该是面向球的一边
            # if dis > 0.25:
            #     #在确定球在左侧的时候，首先确保面向朝左边，再走路
            #     if ball_y - robot_y > 0.25:
            #         aim_angle = -1.57 
            #         if self.check_angle(robot_angle,aim_angle,ANGLE_TOLERANCE) == False:
            #             state = self.change_angle_state(robot_angle,aim_angle,ANGLE_TOLERANCE)
            #             return state
            #         state = 'forward'

            #     #横向距离在可接受范围内
            #     elif ball_y - robot_y > 0 and ball_y - robot_y < 0.25:
            #         #进了这个if并且横向距离在可接受范围内纵向坐标必然过大
            #         if self.check_angle(robot_angle,normal_angle,ANGLE_TOLERANCE) == False:
            #                 state = self.change_angle_state(robot_angle,normal_angle,ANGLE_TOLERANCE)
            #                 return state
            #         else:
            #             state = 'forward'
            #             return state
                    
            #     if ball_y - robot_y < -0.25:
            #         aim_angle = 1.57 
            #         if self.check_angle(robot_angle,aim_angle,ANGLE_TOLERANCE) == False:
            #             state = self.change_angle_state(robot_angle,aim_angle,ANGLE_TOLERANCE)
            #             return state
            #         state = 'forward'

            #     elif ball_y - robot_y < 0 and ball_y - robot_y > -0.25:
            #         #进了这个if并且横向距离在可接受范围内纵向坐标必然过大
            #         if self.check_angle(robot_angle,normal_angle,ANGLE_TOLERANCE) == False:
            #                 state = self.change_angle_state(robot_angle,normal_angle,ANGLE_TOLERANCE)
            #                 return state
            #         else:
            #             state = 'forward'
            #             return state

            if dis > self.accu_kick_threshold:
                #距离很远的情况，优先找到机器人距离球的方向进行转向
                deg = self.calculate_angle_to_ball(robot_x,robot_y,ball_x,ball_y)

                if self.check_angle(robot_angle,deg,ANGLE_TOLERANCE_MAX) == False:
                    print("阶段2调整中")
                    state = self.change_angle_state(robot_angle,deg)
                    return state
                else:
                    
                    state = 'forward'
                    return state
            print("完成阶段2")
            self.state_tree_index = 3
        #end_if_state_2
            
        #--------------------------------------------
        #--------判断阶段3----------------------------
        #--------------------------------------------
        #在这个阶段机器人距离球的距离小于0.5m，比较好开始踢球
        #踢球过程如下：
        #找到击球点与小球的角度，调整角度至相似
        #左右移动到满足条件（判断左右脚）
        #前后移动到满足条件
        #踢球
        if self.state_tree_index == 3:
            deg = self.calculate_angle_to_ball(ball_x,ball_y,aim_x,aim_y)

            if self.check_angle(robot_angle,deg,ANGLE_TOLERANCE) == False:
                print("阶段3调整中")
                state = self.change_angle_state(robot_angle,deg)
                return state
            else:
                state = self.get_fine_tuning_state(robot_x,robot_y,ball_x,ball_y,'right')

        return state
                
    def get_fine_tuning_state(self, robot_x, robot_y, ball_x, ball_y, kick_leg):

    
        # --- 【暴露的调试参数】 ---
        # 1. 击球纵向距离 (Y轴)：机器人中心到球的距离
        # 距离太近会撞球，太远踢不到。建议范围 [0.16 - 0.22]
        OFFSET_X = 0.20  
        
        # 2. 击球横向偏移 (X轴)：球相对于机器人中心线的左右偏移
        # 越大代表球离身体中心越远（靠外侧）。建议范围 [0.05 - 0.09]
        OFFSET_Y = 0.07  
        
        # 3. 容差范围：在这个误差内认为已经对准
        TOLERANCE = 0.02 
        # -----------------------

        # 计算相对位移 (在面向 -Y 的坐标系下)
        # dx > 0 说明球在右，dx < 0 说明球在左
        dx = ball_x - robot_x
        
        # dy = robot_y - ball_y (因为面向-Y，机器人Y大，球Y小)
        dy = robot_y - ball_y

        # --- 核心逻辑：根据预定踢球腿计算目标 X 偏移 ---
        # 如果确定用右脚：理想情况是球在机器人右侧 OFFSET_Y 处
        # 如果确定用左脚：理想情况是球在机器人左侧 -OFFSET_Y 处
        target_dx = OFFSET_Y if kick_leg == 'right' else -OFFSET_Y

        # --- 状态判断流 ---
        
        # 1. 纵向判断 (前后移动)
        # 如果距离球太远，先靠近
        if dx > (OFFSET_X + TOLERANCE):
            return 'forward'
        elif dx < (OFFSET_X - TOLERANCE):
            return 'back'

        # 2. 横向判断 (左右挪动)
        # 这里的 dx 是当前球的位置，target_dx 是球应该在的位置
        if dx > (target_dx + TOLERANCE):
            # 球太偏右了，机器人需要往右挪来让球相对往左移
            # 或者说机器人相对于球偏左了
            return 'turn_right' 
        elif dx < (target_dx - TOLERANCE):
            # 球太偏左了，机器人需要往左挪
            return 'turn_left'

        # 3. 纵向与横向均在容差内，执行踢球
        return 'kick'
                



    #函数将原来find_state中有关角度判断的函数整合
    #函数check_angle用来判断当前angle与想要的angle的差值是否在可接受范围内
    #如果是，返回True，否则返回False
    def check_angle(self,robot_angle,aim_angle,tolerance):

        adjust_ang = abs(robot_angle - aim_angle)
        if adjust_ang > 3.14 :
            adjust_ang = 6.28 - adjust_ang

        if( adjust_ang > tolerance ):
            print(adjust_ang)
            return False
        else:
            return True
        
        
    #该函数在机器人的偏角与目目标偏角有区别的时候调用，
    #输入为当前机器人角度和目标角度
    #返回值为state，控制下一步的动作
    def change_angle_state(self,robot_angle,aim_angle):
        
        turn_flag = 0
        adjust_ang = abs(robot_angle - aim_angle)
        
        if adjust_ang > 3.14 :
            adjust_ang = 6.28 - adjust_ang
            turn_flag = 1

        if  (robot_angle - aim_angle > 0 and turn_flag == 0) or \
            (robot_angle - aim_angle < 0 and turn_flag == 1) :
            #右转
            if adjust_ang > BIG_DEGREEN:
                now_state = 'turn_left_180'
            elif adjust_ang > SIXTY_DEGREEN:
                now_state = 'turn_right_60'
            elif adjust_ang > FORTY_DEGREEN:
                now_state = 'turn_right_40'
            else :
                now_state = 'turn_right_08'
        if  (robot_angle - aim_angle < 0 and turn_flag == 0) or \
            (robot_angle - aim_angle > 0 and turn_flag == 1) :
            #右转
            if adjust_ang > BIG_DEGREEN:
                now_state = 'turn_left_180'
            elif adjust_ang > SIXTY_DEGREEN:
                now_state = 'turn_left_60'
            elif adjust_ang > FORTY_DEGREEN:
                now_state = 'turn_left_40'
            else :
                now_state = 'turn_left_08'
        return now_state
        
    
    def calculate_angle_to_ball(self, robot_pos_x, robot_pos_y, ball_pos_x, ball_pos_y):
        rx, ry = robot_pos_x, robot_pos_y
        bx, by = ball_pos_x, ball_pos_y

        # 计算相对位移
        dx = bx - rx
        dy = by - ry

        # 关键修正：因为你的数据方向与逻辑定义正好相反
        # 我们对 dx 和 dy 取反，这样：
        # 视觉上的“前”会变成负方向，视觉上的“右”会变成正方向
        angle = math.atan2(-dy, dx)

        return -angle




    #  废案
    # def find_best_shoot_place(self,ball_x,ball_y,shoot_leg):
        
    #     door_x = self.door_x

    #     if( door_x > 0 ):
    #         multi_bias =  1
    #     else: 
    #         multi_bias = -1

    #     if shoot_leg == RIGHT_LEG:
    #         bias_x = -0.225 * multi_bias
    #         bias_y = 0.0725 * multi_bias
    #     elif shoot_leg == LEFT_LEG:
    #         bias_x = -0.225 * multi_bias
    #         bias_y = -0.0725 * multi_bias
    #     else:
    #         bias_x = -0.225 * multi_bias
    #         bias_y = 0.0725 * multi_bias

    #     best_pos_x = ball_x + bias_x
    #     best_pos_y = ball_y + bias_y

    #     #假设球在0点，对于黑队来说最佳击球点为-0.225.
    #     #踢球点可以更接近球，也就是击球点可以更小，假设最小是-0.17
    #     #差距为（0.055 + 0.005），需要确定下最下跨步单位为多少

    #     #y轴方向差也为0.06
    #     min_shoot_x = best_pos_x - 0.065 * multi_bias 
    #     max_shoot_x = best_pos_x + 0.055 * multi_bias 

    #     min_shoot_y = best_pos_y - 0.015 * multi_bias
    #     max_shoot_y = best_pos_y + 0.045 * multi_bias


    #     return max_shoot_x,min_shoot_x,max_shoot_y,min_shoot_y

    #  废案
    # def find_best_shoot_place(self, ball_x, ball_y, shoot_leg):
    #     door_x = self.door_x
    #     # 确定朝向：1为正向，-1为负向
    #     multi_bias = 1 if door_x > 0 else -1

    #     # 基础偏置计算 (这里建议直接写死绝对偏移，后面再处理方向)
    #     # 假设无论朝向哪，击球点都在球后方 0.225 米
    #     bias_x = -0.225 * multi_bias 
        
    #     if shoot_leg == LEFT_LEG:
    #         bias_y = -0.0725 * multi_bias
    #     else:
    #         bias_y = 0.0725 * multi_bias

    #     best_pos_x = ball_x + bias_x
    #     best_pos_y = ball_y + bias_y

    #     # 计算四个边界值
    #     # 注意：这里我们先计算出两个点，然后用 min/max 确保顺序正确
    #     x_val1 = best_pos_x - 0.065 * multi_bias
    #     x_val2 = best_pos_x + 0.055 * multi_bias
        
    #     y_val1 = best_pos_y - 0.015 * multi_bias
    #     y_val2 = best_pos_y + 0.045 * multi_bias

    #     # 关键修复：确保第一个返回值是小的，第二个是大的
    #     return min(x_val1, x_val2), max(x_val1, x_val2), min(y_val1, y_val2), max(y_val1, y_val2)
    
    def find_best_shoot_place(self,ball_x,ball_y,shoot_leg):
        
        door_x = self.door_x
        door_y = self.door_y

        if( door_x > 0 ):
            multi_bias =  1
        else: 
            multi_bias = -1

        if shoot_leg == RIGHT_LEG:
            bias_x = -0.215 * multi_bias
            bias_y = 0.0725 * multi_bias
        elif shoot_leg == LEFT_LEG:
            bias_x = -0.215 * multi_bias
            bias_y = -0.0725 * multi_bias
        else:
            bias_x = -0.215 * multi_bias
            bias_y = 0.0725 * multi_bias

        best_pos_x = ball_x + bias_x
        best_pos_y = ball_y + bias_y

        return best_pos_x,best_pos_y
    
    #根据目标点找到最佳的击球地点，传球相关函数，状态树相关调用
    #根据球的坐标，目标点的坐标计算最佳的击球点
    #可调参数为机器人与球的垂直向距离
    #abs(aim_x)
    def find_the_best_kick_place(self,ball_x,ball_y,aim_x,aim_y):

        #待调试，击球点与球的距离
        shoot_dis = 0.225

        #判断距离是否为0防止除以0
        dis = math.sqrt( (aim_x - ball_x)**2 + (aim_y - ball_y)**2 )
        if dis == 0:
            return ball_x, ball_y
        
        #计算单位向量
        u_x = (aim_x - ball_x) / dis
        u_y = (aim_y - ball_y) / dis

        pos_x = ball_x - u_x * shoot_dis
        pos_y = ball_y - u_y * shoot_dis

        return pos_x,pos_y

    #击球手力度太低，守门员只用左右移动
    def get_state_keeper(self):

        self.reciever.update()
        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        robot_angle = self.reciever.get_robot_angle()

        now_state = 'Hand_Wave'

        if(robot_y != None ):
            if((robot_y - ball_y) < 0.0):
                now_state = 'turn_left'
            elif((robot_y - ball_y) > 0.12):
                now_state = 'turn_right'

        return now_state
    
    #击球手力度太低，守门员只用左右移动
    def get_state_defender(self):

        
        self.reciever.update()
        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        robot_angle = self.reciever.get_robot_angle()

        now_state = 'Hand_Wave'

        #根据命名设置不同的门的位置
        if self.name == 'Red_Defender_1' or self.name == 'Red_Defender_2':
            Door_x = 4.5
        if self.name == 'Black_Defender_1' or self.name == 'Black_Defender_2':
            Door_x = -4.5
        else: print("wrong funciton")

        #根据1/2控制不同的逻辑（1为激进防御手，2为控球防御手）
        if self.name == 'Red_Defender_1' or self.name == 'Black_Defender_1':
            now_state = 'Hand_Wave'



        return now_state


    #下面的逻辑更新完成一个目的，让机器人在前方有人时能够绕开踢球

    #由于现在最好只能直击，因此在每次击球前考虑，球与进球点之间有没有人
    #如果没有人，则执行kick逻辑，且目标点设置为进球点
    #如果有人，则重设一个进球点，（pos_x,pos_y+1）
    #即让机器人将球往右踢一点(一直加直到确认击球线中没人)
    

    # 如何判断进球
    # 球的坐标x<-4.5 或x>4.5  且 0.8>y>-0.8

    # 如何判断球达到传球点位置
    # 球和传球点的距离小于Tolerance，或(ball_y-robot_y) > (pos_y-robot_y)
    # 如果判断达到传球点，则讲传球点设置为进球点

    # 由于机器人每一次walk都是朝向进球点(传球点)
    # 如果方向是正确的话，每一次walk_loop后，x轴的距离都会减少一个范围
    # 如果减少的范围小于设定的值，则此时可能方向错了
    # 根据少走的值判断该旋转多少度
    # 根据y轴的偏移考虑改左转还是右转

    # 假设每走一步对x轴的贡献值为 k
    # 当前loop的贡献值为 n
    # if (n<k): 需要调整方向
    # elif (n < 0) :走反了
        
    


