from controller import Robot, Keyboard, Motion
from VisionLib import VisionReviewer
import math
import os


#v1.1新增，为后续开发准备
RED_TEAM_FLAG  = -1
BLUE_TEAM_FLAG = 1

#V1.1新增，作为角度容忍值，偏离3.14 +-0.15都是可以接受的，也是转向8度能补偿的最小值
ANGLE_TOLERANCE = 0.20

#V1.4新增，最大角度容忍，避免机器人在斜线行走过程中频繁改变角度,大概40度
ANGLE_TOLERANCE_MAX = 0.8

#V1.1 新增，作为阈值配置指导机器人寻找正确的motion
BIG_DEGREEN   = 2.5
SIXTY_DEGREEN = 1.2
FORTY_DEGREEN = 0.75


GO_FORWARD = 1
GO_BACK    = 2
TURN_RIGHT = 3
TURN_LEFT  = 4
SHOOT      = 0

DOOR_POS_X_B = -4.25
DOOR_POS_X_R = 4.25
DOOR_POS_Y_B = 0
DOOR_POS_Y_R = 0

RIGHT_LEG = 0
LEFT_LEG  = 1
#最后一帧留给stop，需要提前停止，滑动窗口计算距离，需要增加值
OFFSET_X_BACK = 0.065
OFFSET_X_FRONT = 0.07
OFFSET_Y_LEFT = 0.018
OFFSET_Y_RIGHT = 0.030

TOLERANCE_Y_R = 0.03
TOLERANCE_Y_L = 0.03
TOLERANCE_X_B = 0.07
TOLERANCE_X_F = 0.07



STATE_CHECK = False

class Logic:
    
    def __init__(self,Nao):

        #V1.2 新增获取机器人名字决定队伍
        self.name = Nao.getName()
        self.visionReviewer = VisionReviewer(Nao)
        self.timeStep = int(Nao.getBasicTimeStep())
        #V1.1 新增，作为机器人正常配置，保持机器人面朝前方
        self.normal_angle = RED_TEAM_FLAG * 3.14

        #存储上一次的状态，用来循环右移左移
        self.last_state = None

        #存储上一次踢球前球的位置，用来判断球是否提到了
        self.last_ball_x = None
        self.last_ball_y = None
        self.kick_adjust_count = 0

        if self.name[:5] == "Black":
            self.team = "Black"
        elif self.name[:3] == "Red":
            self.team = "Red"
        else:
            print("illegal_name!!")
        
        if self.team == 'Black':
            self.door_x = DOOR_POS_X_B
            self.door_y = DOOR_POS_Y_B
        else:
            self.door_x = DOOR_POS_X_R
            self.door_y = DOOR_POS_Y_R

        self.kick_data = []



        #传球判断相关
        self.passball_pos = {
            'goal_center':(-4.5,0),
            'goal_left':(-4.5,-1.5),
            'goal_right':(-4.5,1.5),
            'mid_left':(-3.25,-1.75),
            'mid_right':(-3.25,1.75),
            'back_left':(-2.25,-1.75),
            'back_right':(-2.25,1.75),
            'abandon':(4.5,-3)
        }

       
        self.priority_list = ['goal_center', 
                              'goal_left', 'goal_right', 
                              'mid_left', 'mid_right',
                              'back_left', 'back_right',
                              'abandon']
        
        traing_file_name = 'Lkick_data.csv'
        self.get_trainning_file(traing_file_name)
        
        self.kick_len = len(self.priority_list)
        
        self.can_i_kick = [False] * self.kick_len



        #状态flag
        self.back_state_flag = 0

        #状态树整体状态flag
        self.state_tree_index = 0

        #阻挡判断相关
        self.obstacle_threshold = 0.15

        #左右移动和向左转后前进的判断
        #当小球在机器人的左右两侧超过1m，则不用左右移动来调整位置
        #直接左右转再前进
        self.side_threshold = 1

        #转向后移动和直接倒退的判断
        #当小球在机器人后方超过一定距离后机器人调头在走向目标点
        self.back_threshold = 1

        #保持球在机器人前方至少0.15m的距离
        self.mindis_ball_robot = 0.15

        #保持机器人与球的横向水平距离大于0.2，以防倒推碰到球
        self.mindis_ball_robot_side = 0.2

        #精细踢球半径
        self.accu_kick_threshold = 0.3

        #踢球点距离球的位置
        self.distance_to_kick = 0.3

        #踢的腿
        self.kick_leg = 'left'
   
    def state_tree(self):

        aim_x = self.door_x
        aim_y = self.door_y

        #默认赋值防止出错
        path_state = 'Hand_Wave'
        finish_state = 'OK'

        fall_state = self.check_robot_fall()
        if fall_state == True:
            return 'StandUp'
        else :
            obstacle_state = self.check_obstacle_in_path()
            if obstacle_state == True:
                aim_x, aim_y = self.update_door_position()
            else:
                pass
            #判断球是否出现大幅度移动（被干扰）如果出现则重新开始逻辑树
            if self.check_ball_move(0.01) == True:
                print('back to state 0')
                self.state_tree_index = 0
            
            if self.state_tree_index == 0:
                if STATE_CHECK: print('state 0')
                path_state = self.find_back_ball()
            if path_state == finish_state or self.state_tree_index == 1:
                if STATE_CHECK:print('state 1')
                path_state = self.close_to_ball(aim_x,aim_y)
            if path_state == finish_state or self.state_tree_index == 2:
                if STATE_CHECK:print('state 2')
                path_state = self.kick_ball(aim_x,aim_y)
                
            if path_state == finish_state :
                print('wrong!!!')
                path_state = 'Hand_Wave'
            return path_state
        
    def check_robot_fall(self):
        self.visionReviewer.update(self.name)
        robot_x,robot_y,robot_z = self.visionReviewer.get_robot_position()
        if(robot_z != None ):
            if( robot_z < 0.18 ):
                return True 
        return False
    
    def check_obstacle_in_path(self):
        return self.visionReviewer.check_obstacle(self.team,self.door_x,self.door_y,self.obstacle_threshold)
    
    def update_door_position(self):

        self.can_i_kick = [True] * self.kick_len
        is_red = (self.team == 'Red')
        for idx, target_name in enumerate(self.priority_list):
            raw_x, raw_y = self.passball_pos[target_name]
            
            if is_red:
                tx, ty = -raw_x, -raw_y
            else:
                tx, ty = raw_x, raw_y

            if not self.visionReviewer.check_obstacle(self.team, tx, ty, self.obstacle_threshold):
                self.can_i_kick[idx] = False  
                return tx, ty
        print('Warning: No clear path found, using default priority target!')
        default_name = self.priority_list[0]
        dx, dy = self.passball_pos[default_name]
        return (-dx, -dy) if is_red else (dx, dy)
    
    
    #V1.5 将plan_path_to_ball函数拆分
    #该函数用来解决球到机器人身后的情况
    #具体注释参照V1.4——01/17版本

    #返回state = 1 表明球在身前
    def find_back_ball(self):

        state = 'Hand_Wave'
        finish_state = 'OK'

        if self.team == 'Black':
            door_pos_x = DOOR_POS_X_B
            normal_angle = 3.14
            back_angle = 0
        else : 
            door_pos_x = DOOR_POS_X_R
            normal_angle = 0
            back_angle = 3.14

        robot_x,robot_y,robot_z = self.visionReviewer.get_robot_position()
        ball_x,ball_y = self.visionReviewer.get_ball_position()
        robot_angle = self.visionReviewer.get_robot_angle()

        if (ball_x is None) or (robot_x is None):
            state = 'Hand_Wave'
            return state
    
        if (abs(ball_x - door_pos_x) - abs(robot_x - door_pos_x ) > -self.mindis_ball_robot):

            if abs(ball_x - robot_x) < self.back_threshold and self.back_state_flag !=1:
                if self.check_angle(robot_angle,normal_angle,ANGLE_TOLERANCE) == False:
                        state = self.change_angle_state(robot_angle,normal_angle)
                        return state
                if abs(ball_y - robot_y) > self.mindis_ball_robot_side :
                    state = 'back'
                    return state
                else:
                    if(ball_y > robot_y):
                        state = 'turn_left'
                        return state
                    else:
                        state = 'turn_right'
                        return state
            else:
                self.back_state_flag = 1
                if self.check_angle(robot_angle,back_angle,ANGLE_TOLERANCE) == False:
                    state = self.change_angle_state(robot_angle,back_angle)
                    return state
                else:
                    state = 'forward'
                    return state

        else:
            self.state_tree_index = 1
            self.back_state_flag = 0

        if self.state_tree_index == 1:
            if self.check_angle(robot_angle,normal_angle,ANGLE_TOLERANCE) == False:
                dis = math.sqrt((robot_x - ball_x)**2 + (robot_y - ball_y)**2)
                if dis >self.side_threshold:
                    if ball_y > robot_y:
                        aim_angle = 1.57 
                    else:
                        aim_angle = -1.57
                    state = self.change_angle_state(robot_angle,aim_angle)
                return state
            else:
                self.state_tree_index = 1
        return finish_state

    #V1.5 将plan_path_to_ball函数拆分
    #该函数用来接近球，使球在机器人可控范围内
    #具体注释参照V1.4——01/17版本

    #仅当state = 1时进入该函数
    #返回state = 2 表明处于控球状态
    def close_to_ball(self,aim_x,aim_y):
        
        state = 'Hand_Wave'
        finish_state = 'OK'

        robot_x,robot_y,robot_z = self.visionReviewer.get_robot_position()
        ball_x,ball_y = self.visionReviewer.get_ball_position()
        robot_angle = self.visionReviewer.get_robot_angle()

        if (ball_x is None) or (robot_x is None):
            state = 'Hand_Wave'
            return state

        dis = math.sqrt((robot_x - ball_x)**2 + (robot_y - ball_y)**2)
        if dis > self.accu_kick_threshold:
            #距离很远的情况，优先找到机器人距离球的方向进行转向
            if ball_y > robot_y: self.kick_leg = 'right'
            else : self.kick_leg = 'left'
            striker_x,striker_2 = self.get_striking_point(aim_x,aim_y,ball_x,ball_y,self.distance_to_kick)
            deg = self.calculate_angle_to_ball(robot_x,robot_y,striker_x,striker_2)

            if self.check_angle(robot_angle,deg,ANGLE_TOLERANCE_MAX) == False:
                state = self.change_angle_state(robot_angle,deg)
                return state
            else:
                
                state = 'forward'
                return state
        self.state_tree_index = 2
        return finish_state 


    #V1.5 将plan_path_to_ball函数拆分
    #该函数在机器人处于控球阶段时调用，用于精细走位进行踢球
    #具体注释参照V1.4——01/17版本

    #仅当state = 2 时进入该函数
    #返回state = 2 表明正在处理踢球动作
    def kick_ball(self,aim_x,aim_y):

        state = 'Hand_Wave'

        robot_x,robot_y,robot_z = self.visionReviewer.get_robot_position()
        ball_x,ball_y = self.visionReviewer.get_ball_position()
        robot_angle = self.visionReviewer.get_robot_angle()

        if (ball_x is None) or (robot_x is None):
            state = 'Hand_Wave'
            return state

        deg = self.calculate_angle_to_ball(ball_x,ball_y,aim_x,aim_y)


        idx = min(range(len(self.kick_data)), key=lambda i: abs(self.kick_data[i][2] - deg))
        if abs(self.kick_data[idx][2] - deg) > 0.1:
            idx = None 

        if idx != None:
            print('已找到相关踢球数据,正在进行校对')
            dx = self.kick_data[idx][0]
            dy = self.kick_data[idx][1]
            
            #优先对准角度
            if self.check_angle(robot_angle,deg,ANGLE_TOLERANCE) == False:
                state = self.change_angle_state(robot_angle,deg)
                return state
            dx_n = ball_x - robot_x
            dy_n = ball_y - robot_y
            print(f"dx:{dx},dy:{dy},nowdx:{dx_n},nowdy:{dy_n}")

            if abs(dy_n - dy)>0.05:
                if dy_n - dy > 0:
                    state = 'sidestepright'
                else :
                    state = 'sidestepleft'
                return state
            if abs(dx_n - dx)>0.05:
                if dx_n - dx > 0:
                    state = 'back'
                else :
                    state = 'forward'
                if dx - dx_n > 0.02:
                    state = 'forward'
                return state
            state = 'kickl'
            return state
                   
        else:
            print("未找到合适的踢球数据,请补充,当前deg为",deg)
            print("下面开始随机踢球")

            if self.check_angle(robot_angle,deg,ANGLE_TOLERANCE) == False:
                state = self.change_angle_state(robot_angle,deg)
                return state
            else:
                if self.kick_leg == 'right': 
                    state = 'kickr'
                else : 
                    state = 'kickl'

        return state



    def check_ball_move(self,threshold):

        ball_x,ball_y = self.visionReviewer.get_ball_position()
        if (ball_x is None) :
            return True
        
        if self.last_ball_x == None :
            self.last_ball_x = ball_x
            self.last_ball_y = ball_y
            return True
        else:
            dis = math.sqrt( (self.last_ball_x - ball_x)**2 + (self.last_ball_y - ball_y)**2 )
            self.last_ball_x = ball_x
            self.last_ball_y = ball_y

        if dis > threshold:
            return True
        else: 
            return False
        
    def check_angle(self,robot_angle,aim_angle,tolerance):

        adjust_ang = abs(robot_angle - aim_angle)
        if adjust_ang > 3.14 :
            adjust_ang = 6.28 - adjust_ang
        if( adjust_ang > tolerance ):
            return False
        else:
            return True
        
    def change_angle_state(self,robot_angle,aim_angle):
        
        turn_flag = 0
        adjust_ang = abs(robot_angle - aim_angle)
        
        if adjust_ang > 3.14 :
            adjust_ang = 6.28 - adjust_ang
            turn_flag = 1

        if  (robot_angle - aim_angle > 0 and turn_flag == 0) or \
            (robot_angle - aim_angle < 0 and turn_flag == 1) :

            if adjust_ang > BIG_DEGREEN:
                now_state = 'turn_left_180'
            elif adjust_ang > SIXTY_DEGREEN:
                now_state = 'turn_right_60'
            elif adjust_ang > FORTY_DEGREEN:
                now_state = 'turn_right_40'
            else :
                now_state = 'turn_right_08'

        if  (robot_angle - aim_angle < 0 and turn_flag == 0) or \
            (robot_angle - aim_angle > 0 and turn_flag == 1) :

            if adjust_ang > BIG_DEGREEN:
                now_state = 'turn_left_180'
            elif adjust_ang > SIXTY_DEGREEN:
                now_state = 'turn_left_60'
            elif adjust_ang > FORTY_DEGREEN:
                now_state = 'turn_left_40'
            else :
                now_state = 'turn_left_08'

        return now_state
        
    
    def calculate_angle_to_ball(self, robot_pos_x, robot_pos_y, ball_pos_x, ball_pos_y):
        rx, ry = robot_pos_x, robot_pos_y
        bx, by = ball_pos_x, ball_pos_y
        dx = bx - rx
        dy = by - ry
        angle = math.atan2(-dy, dx)
        return -angle

    def get_striking_point(self,target_x, target_y, ball_x, ball_y, distance):
        dx = target_x - ball_x
        dy = target_y - ball_y
        line_len = math.sqrt(dx**2 + dy**2)
        if line_len == 0:
            return ball_x, ball_y
        
        strike_x = ball_x - (dx / line_len) * distance
        strike_y = ball_y - (dy / line_len) * distance
        
        return strike_x, strike_y
    
    def find_best_shoot_place(self,ball_x,ball_y,shoot_leg):

        door_x = self.door_x
        door_y = self.door_y

        if( door_x > 0 ):
            multi_bias =  1
        else: 
            multi_bias = -1

        if shoot_leg == RIGHT_LEG:
            bias_x = -0.215 * multi_bias
            bias_y = 0.0725 * multi_bias
        elif shoot_leg == LEFT_LEG:
            bias_x = -0.215 * multi_bias
            bias_y = -0.0725 * multi_bias
        else:
            bias_x = -0.215 * multi_bias
            bias_y = 0.0725 * multi_bias

        best_pos_x = ball_x + bias_x
        best_pos_y = ball_y + bias_y

        return best_pos_x,best_pos_y
    

    def find_the_best_kick_place(self,ball_x,ball_y,aim_x,aim_y):

        shoot_dis = 0.225

        dis = math.sqrt( (aim_x - ball_x)**2 + (aim_y - ball_y)**2 )
        if dis == 0:
            return ball_x, ball_y
        
        u_x = (aim_x - ball_x) / dis
        u_y = (aim_y - ball_y) / dis

        pos_x = ball_x - u_x * shoot_dis
        pos_y = ball_y - u_y * shoot_dis

        return pos_x,pos_y

    def get_state_keeper(self):

        self.reciever.update()
        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        robot_angle = self.reciever.get_robot_angle()

        now_state = 'Hand_Wave'

        if(robot_y != None ):
            if((robot_y - ball_y) < 0.0):
                now_state = 'turn_left'
            elif((robot_y - ball_y) > 0.12):
                now_state = 'turn_right'

        return now_state
    
    def get_state_defender(self):

        self.reciever.update()
        robot_x,robot_y,robot_z = self.reciever.get_robot_position()
        ball_x,ball_y = self.reciever.get_ball_position()
        robot_angle = self.reciever.get_robot_angle()

        now_state = 'Hand_Wave'

        #根据命名设置不同的门的位置
        if self.name == 'Red_Defender_1' or self.name == 'Red_Defender_2':
            Door_x = 4.5
        if self.name == 'Black_Defender_1' or self.name == 'Black_Defender_2':
            Door_x = -4.5
        else: print("wrong funciton")

        #根据1/2控制不同的逻辑（1为激进防御手，2为控球防御手）
        if self.name == 'Red_Defender_1' or self.name == 'Black_Defender_1':
            now_state = 'Hand_Wave'

        return now_state
    

    def get_trainning_file(self,filename):
        
        current_dir = os.path.dirname(__file__)
        file_path = os.path.join(current_dir, filename)

        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 3:
                        row = [float(parts[0]), float(parts[1]), float(parts[2])]
                        self.kick_data.append(row)
            print(f"read {len(self.kick_data)} data")
        else:
            print("wrong!cant find file")
        
    


