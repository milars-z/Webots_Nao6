## For Vision part
## Now use reviever to get the position of ball and robot

from Receiver import receiver
import math
           

class VisionReviewer:
    def __init__(self, Nao):
        timestep = int(Nao.getBasicTimeStep())

        self.receiver = receiver(Nao)

        self.ball_x = None
        self.ball_y = None
        self.robot_x = None
        self.robot_y = None
        self.robot_z = None
        self.robot_x_val = 0.0
        self.robot_y_val = 0.0  
        self.robot_z_val = 0.0
        self.robot_x_arr = [0] * 3
        self.robot_y_arr = [0] * 3
        self.robot_z_arr = [0] * 3

        self.setball = 0
        self.setrobot = 0

        #处理进球后重置
        self.flag = 0

        
        self.iu = Nao.getDevice("inertial_unit")
        self.iu.enable(timestep)
        
        self.old_yaw = 0
        self.standard_yaw = 0

    def update(self,robot_name):

        ball_x, ball_y, robot_x, robot_y, robot_z, flag = self.receiver.get_all_positions(robot_name)

        if ball_x is not None:
            self.ball_x = ball_x
            self.ball_y = ball_y
            self.setball = 1
            self.flag = flag


        if robot_x is not None and robot_y is not None and robot_z is not None:

            self.setrobot = 1

            # self.robot_x_arr.pop(0)
            # self.robot_y_arr.pop(0)
            # #self.robot_z_arr.pop(0)
            # self.robot_x_arr.append(robot_x)
            # self.robot_y_arr.append(robot_y)
            #self.robot_z_arr.append(robot_z)

            # self.robot_x_val = (self.robot_x_arr[0] + self.robot_x_arr[1] + self.robot_x_arr[2]) / 3.0
            # self.robot_y_val = (self.robot_y_arr[0] + self.robot_y_arr[1] + self.robot_y_arr[2]) / 3.0
            #self.robot_z_val = (self.robot_z_arr[0] + self.robot_z_arr[1] + self.robot_z_arr[2]) / 3.0

            self.robot_x_val = robot_x
            self.robot_y_val = robot_y
            self.robot_z_val = robot_z

    def get_ball_position(self):
        if self.setball == 0:
            return None, None
        return self.ball_x, self.ball_y

    def get_robot_position(self):
        if self.setrobot == 0:
            return None, None, None
        return self.robot_x_val, self.robot_y_val, self.robot_z_val
    

    def get_robot_angle(self):
        roll_pitch_yaw = self.iu.getRollPitchYaw()
        yaw = roll_pitch_yaw[2] 
        return yaw
    
    # def get_robot_angle(self):
    #     roll_pitch_yaw = self.iu.getRollPitchYaw()
    #     current_yaw = roll_pitch_yaw[2] 
        
    #     if current_yaw - self.old_yaw < -4:
    #         self.total_offset += 2 * math.pi

    #     elif current_yaw - self.old_yaw > 4:
    #         self.total_offset -= 2 * math.pi
        
    #     self.old_yaw = current_yaw
    #     aa = current_yaw + self.total_offset
    #     print("Yaw with offset:", aa)
    #     return current_yaw + self.total_offset 

    def get_flag(self):
        return self.flag
    

    def check_obstacle(self,team,target_x,target_y,threshold):
        return self.receiver.check_obstacle(team,target_x,target_y,threshold)   
        
    
